﻿
using System;
using System.Runtime.InteropServices;

internal class Program
{
    private static void Main(string[] args)
    {
         
        Console.Clear();
        Console.WriteLine("Você começa a jornada num pasto (como um qualquer). Qual o seu primeiro objtivo?");
        Console.WriteLine("1 - Floresta");
        Console.WriteLine("2 - Colinas");
        

        string escolha = Console.ReadLine() ?? "";

        if (escolha == "1")
        {
            Console.WriteLine("Você segue caminho floresta adentro sem problemas.");
            Floresta();
        }
        else
        {
            Console.WriteLine("Final 1/?: Nasceu, e morreu como um 'zé ninguém'.");
            Console.WriteLine("Você foi até as colinas, porém, havia um enorme.. antes mesmo de tentar compreender, ele te bate, com isso você (obviamente) morre. Quem sabe algum dia você ressurge para uma vingança.");    
        }
         
        


        static void Floresta()
        {
            Console.Clear();
            Console.WriteLine("A floresta era bem calma até, você consegue caminhar livremente por lá. Entretanto, observando de longe, havia um grupo de marginais conversando, qual caminho você irá trilhar agora?");
            Console.WriteLine("1 - Ir até eles e dialogar");
            Console.WriteLine("2 - Apenas contornar");

            string escolha = Console.ReadLine() ?? "";

            if (escolha == "1")
            {
                Console.WriteLine("Lentamente você caminhou até eles, com muito receio obviamente, mas o que poderia dar de errado?");
                Console.WriteLine("1");

                string escolha2 = Console.ReadLine() ?? "";

                if (escolha2 == "1")
                {
                     Marginais();
                }
            }
            else
            {
              Console.WriteLine("Bom, às vezes ignorar algumas coisas também serve, e não é como se você fosse um grande herói corajoso e fortão, então acaba que eles nem percebem você correndo atrás das árvores com medo.");
              Console.WriteLine("1");

              string escolha2 = Console.ReadLine() ?? "";

              if(escolha2 == "1")
              {
              Floresta2();
              }   
            }
        }   
            static void Marginais()
            {
                Console.Clear();
                Console.WriteLine("Despretenciosamente, lá foi você conversar com os marginais. Eles te avistam, não aparentavam ser do mal.. e não eram mesmo. Você conversa bastante com os 5 marginais, eles vêem sua decadência de vida, então não demora muito até você fazer parte do grupo.");
                Console.WriteLine("Com seu novo grupo vocês caminham até uma vila com o nascer do sol, onde bastou uma pessoa reconhecer vocês e pronto, vários guardas armados vieram em suas direções, o que você pretende fazer?");
                Console.WriteLine("1 - lutar junto dos marginais.");
                Console.WriteLine("2 - Fugir");

                string escolha = Console.ReadLine() ?? "";

                if (escolha == "1")
                {
                  Console.WriteLine("'Atacar!' Gritou o líder dos marginais, com isso, 6 pessoas contra, teoricamente uma vila inteira começaram uma guerra, entretanto, você nunca tinha lutado e nem atirado antes, porém você conseguiu não ser inútil, arremessava pedras nos cidadões do vilarejo, e alertava possíveis ameaças durante a guerrilha.");
                  Console.WriteLine("Não se sabe quantas pessoas foram desvividas no processo, mas ninguém do seu novo grupo saiu morto. Conseguiram se escontar nos fundos do vilarejo, e aos poucos você ia percebendo que eles realmente não eram do mal, eles queriam justiça.");
                  Console.WriteLine("1");
                  string escolha2 = Console.ReadLine() ?? ""; 
                  if(escolha2 == "1")
                  {
                  vilarejo();
                  }

                }
                else
                {
                    Console.WriteLine("Final 3/?: Covarde."); 
                    Console.WriteLine("Você abandonou seu novo grupo quando eles mais precisavam, por causa disso um deles esmagou sua cabeça diante o chão: 'Eu esperava mais de você' disse o líder.");
                }
                
                
            }

            static void Floresta2()
            {
                Console.Clear();
                Console.WriteLine("Os marginais já estavam longe o bastante para se acalmar. Você decide montar um 'acampamento' para descansar, já estava ficando escuro.");
                Console.WriteLine("Enquanto você estava descansando, durante seu sono, pairou algumas ideias em sua mente, qual você vai querer por em prática?");
                Console.WriteLine("1 - Se dar um nome");
                Console.WriteLine("2 - Levantar-se e procurar alguma coisa");

                string escolha = Console.ReadLine() ?? "";
                if (escolha == "1")
                {
                  Console.Clear();
                  Console.WriteLine("Final 2/?: O destino tem suas escolhas");
                  Console.WriteLine("Você pensa por muito tempo em um nome, porém.. ao enfim pensar em um, um meteoro caiu na sua cabeça, agora todas as pessoas que passam por ali te chamam de 'cabeça de meteoro', melhor que nada, não?");
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Você se levantou com o pôr do sol, e caminhou até uma macieria, você refletiu, por muito tempo.. até chegar um outro cara embaixo da macieira, um tempo passou, e uma maçã caiu na cabeça dele, depois disto acontecer ele ficou chocado e saiu correndo ao horizonte, você ficou confuso, mas ignorou.");
                    Console.WriteLine("1");

                    string escolha2 = Console.ReadLine() ?? "";

                    if(escolha2 == "1")
                    {
                    Macieira();
                    }
                }
            }

            static void Macieira()
            {
              Console.Clear();
              Console.WriteLine("Após aquilo, você decide continuar o seu caminho, pegou suas coisas e foi embora. Ao caminhar um pouco, você vê um vilarejo, que não está muito convidativo, o vilarejo ta sendo atacado. De longe você vê uma pessoa fugindo, indo pra longe de lá, o que você faz?");
              Console.WriteLine("1 - Vai atrás");
              Console.WriteLine("2 - Continua seu caminho");

              string escolha = Console.ReadLine() ?? "";

              if(escolha == "1")
                {
                    Console.WriteLine("Você começa a correr atrás daquela pessoa, você nao sabe as intenções dela, mas espera ser boas.");
                    Console.WriteLine("1");

                    string escolha2 = Console.ReadLine() ?? "";

                    if(escolha2 == "1")
                    {
                      pessoa();  
                    }
                }
                else
                {
                    Console.WriteLine("Final 4/?: Tranquilidade");
                    Console.WriteLine("Você não seguiu aquela pessoa, logo você realmente não quis ir até o vilarejo, e meio que você não se importou nem um pouco. Pelo menos você não morreu, e encontrou um lugar bacana pra ficar.");
                }
            }

            static void vilarejo()
            {
              Console.Clear();
              Console.WriteLine("Eles explicam tudo do que você precisava saber, o rei fazia as pessoas viverem na mentira, entre vários outros problemas, a hora de revidar era aquela, então o que você sugere?");
              Console.WriteLine("1 - Dar uma sugestão");
              Console.WriteLine("2 - Questioná-los");

              string escolha = Console.ReadLine() ?? "";

              if(escolha == "1")
                {
                    Console.WriteLine("Você deu uma bela sugestão, duas pessoas do grupo se entregavam, e quando fossem para guilhotina o restante mataria o rei e seus lacaios: 'nada mal' disseram pra você.");
                    Console.WriteLine("1");

                    string escolha2 = Console.ReadLine() ?? "";

                    if(escolha2 == "1")
                    {
                      rei();
                    }
                }
                else
                {
                    Console.WriteLine("Você os questionou: 'mas precisa disso mesmo? Não é só conversar com ele?' um silêncio se instaura na sala.");
                    Console.WriteLine("Final 5/?: infelizmente não é igual Disney");
                    Console.WriteLine("Eles acharam que você era um infiltrado, já tinha acontecido isso uma vez, como você não sabia, tomou de trivela.");
                }
            }

            static void pessoa()
            {
              Console.Clear();
              Console.WriteLine("Ele fez uma pausa atrás da árvore, como você já estava perto, tentou diálogar com ela, a pessoa então ficou assustada, e partiu para cima de ti, qual seu próximo passo?");
              Console.WriteLine("1 - Tentar se defender");
              Console.WriteLine("2 - Correr");

              string escolha = Console.ReadLine() ?? "";

              if(escolha == "1")
                {
                    Console.WriteLine("Enquanto a pessoa te bate você 'se defende' e tenta conversar com ela, dizendo que você não faz parte de nada, e que é novo ali: Como posso acreditar em você?");
                    Console.WriteLine("1 - 'Não sei'");
                    Console.WriteLine("2 - Tentar provar de alguma forma");

                    string escolha2 = Console.ReadLine() ?? "";

                    if(escolha2 == "1")
                    {
                        Console.WriteLine("Ele fica ainda mais estressada com você, e te da um murro tão forte que sua cabeça voa para longe.");
                        Console.WriteLine("Final 6/?: Nem servir pra falar você serve");
                        Console.WriteLine("Você fica estirado no chão, e é esquecido.");
                    }
                    else
                    {
                        Console.WriteLine("Você tenta demonstrar que não tinha tatuagens, não reconhecia nomes, não tinha marcas de briga, então a pessoa começou a confiar ao menos um pouco em você.");
                        Console.WriteLine("1");

                        string escolha3 = Console.ReadLine() ?? "";

                        if(escolha3 == "1")
                        {
                        caminhada();
                        }
                    }
                    
                }

            }

            static void rei()
            {
               Console.Clear();
               Console.WriteLine("Os dois cobaias foram se entregar, e no mesmo dia, foram condenados. Após meia hora, todos estavam em seus postos, mas.. onde estava o rei? Vocês começam a caçar o rei, enquanto os dois estão na guilhotina, você não sabe o momento da execução, então o que você decide fazer?");
               Console.WriteLine("1 - Caçar o rei");
               Console.WriteLine("2 - Salvar os seus aliados");
               
               string escolha = Console.ReadLine() ?? "";

               if(escolha == "1")
            {
                Console.WriteLine("É uma escolha muito acirrada que você decide fazer, e você não tem a aprovação de todos, então você foi sozinho buscar o rei.");
                Console.WriteLine("1");

                string escolha2 = Console.ReadLine() ?? "";

                if(escolha2 == "1")
                {
                   matarrei();
                }
                else
                {
                    Console.WriteLine("Você decide salvar seus aliados, afinal se eles morrerem você vai ficar com isso pelo resto de sua vida, então, vocês conseguem salvar os dois cobaias, e agora além de precisarem encontrar o rei, precisavam fugir dali.");
                    Console.WriteLine("1");

                    string escolha3 = Console.ReadLine() ?? "";

                    if(escolha3 == "1")
                    {
                        fugir();
                    }
                }
            }
            }

            static void matarrei()
        {
            Console.Clear();
            Console.WriteLine("Enquanto os outros estavam escondidos na missão de salvar os dois amigos, você foi sorrateiramente andando pelo vilarejo em busca do rei, você se depara com alguns guardas, o que você vai fazer?");
            Console.WriteLine("1 - Se esconder");
            Console.WriteLine("2 - Lutar");

            string escolha = Console.ReadLine() ?? "";

            if(escolha == "1")
            {
                Console.WriteLine("Você se esconde atrás de uns caixotes. A cada passo é difícil a percepção de se eles estão ou não perto de ti, a verdade é uma só na verdade, eles te encherão de porrada, tu ficou igual uma bola com capa furada, daí tu morreu.");
                Console.WriteLine("Final 7/?: Seria melhor pelo menos tentar revidar.");
                Console.WriteLine("Acabou que os marginais fugiram, e você virou comida de cachorro, agora você provávelmente é só mais uma pilha de merda, literalmente.");
            }
            else
            {
                Console.WriteLine("Você foi para cima dos guardas, confiante, no mais era só isso que você tinha mesmo.");
                Console.WriteLine("1");

                string escolha2 = Console.ReadLine() ?? "";

                if(escolha2 == "1")
                {
                  luta();
                }
            }
        }


            static void caminhada()
                {
                  Console.Clear();
                  Console.WriteLine("Vocês vão caminhando entre as árvores, a pessoa lhe explica o que estava acontecendo, definitivamente era muita coisa.");
                  Console.WriteLine("Acaba que se forma uma amizade ali, certo que os dois estavam se desconfiando, porém uma amizade:");
                  Console.WriteLine("1 - Mas.. alguma hora você vai.. querer voltar lá?");
                  Console.WriteLine("2 - Qual o seu objetivo agora?");

                  string escolha = Console.ReadLine() ?? "";

                  if(escolha == "1")
                {
                Console.WriteLine("Eu não vejo futuro ali, porém, talvez. Caso você esteje disposto a me ajudar.");
                Console.WriteLine("1 - A mas isso é problema seu.");
                Console.WriteLine("Eu te ajudo, se eu conseguir.");

                string escolha2 = Console.ReadLine() ?? "";

                if(escolha2 == "1")
                {
                  Console.WriteLine("Bom, acho que você vai servir de algo então.");
                  Console.WriteLine("Final 8/?: Armamento.");
                  Console.WriteLine("Você deveria ter pensado em ajudar, pelo menos você não iria virar adagas e flechas para uma vingança.. mas a ideia da pessoa foi boa entretanto.");  
                }
                else
                {
                  Console.WriteLine("*uma pausa dramatica acontece*.. Vamos fazer assim então..");
                  Console.WriteLine("1");

                  string escolha3 = Console.ReadLine() ?? "";

                  if(escolha3 == "1")
                    {
                        vingança();
                    }
                }
                }
            else
            {
              Console.WriteLine("Falar pra você, eu não sei, porém, tem um bixo, que quero ver, acertar as contas.");
              Console.WriteLine("1");

              string escolha4 = Console.ReadLine() ?? "";

              if(escolha4 == "1")
                {
                    bixo();
                }
            }
                }

            static void fugir()
        {
            Console.Clear();
            Console.WriteLine("Todos do vilarejo perseguiam vocês, eram realmente muitos, alguns eram derrubados, alguns mortos, mas vôcrs 6 estavam vivos e correndo.");
            Console.WriteLine("Chegou em um ponto que não veria mais a opção de fugir, já que todos os lugares possíveis estavam sendo cercados a sua volta, neste caso, o que você vai fazer?");
            Console.WriteLine("1 - Se camuflar");
            Console.WriteLine("2 - Tentar revidar a multidão");

            string escolha = Console.ReadLine() ?? "";

            if(escolha == "1")
            {
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine("Final 9/?: O que?");
                Console.WriteLine("Eu não sei em que mundo você se viu onde 6 pessoas cansadas lutavam contra um vilarejo inteiro (dessa vez literalmente).");
                Console.WriteLine("Porém, um dragão de 15 cabeças aparece, e salva vocês, agora o grupo dos marginais tem um dragrão, e uma dimensão inteira só para eles, afinal, não tem dragões aqui.");
            }
        }

        static void luta()
        {
            Console.Clear();
            Console.WriteLine("Você foi todo atrapalhado, não tinha noção de nada, mas mesmo assim você conseguiu escapar deles.");
            Console.WriteLine("Claro que no processo você tinha caído no chão, com isso você fez um 'sand attack' nos guardas, o que levou você a fugir.");
            Console.WriteLine("Enquanto fugia, você deu de cara com uma grande porta, na qual você não sabe onde vai dar:");
            Console.WriteLine("1 - Empurrar");
            Console.WriteLine("2 - Continuar para outro lado");

            string escolha = Console.ReadLine() ?? "";

            if(escolha == "1")
            {

                {
              Console.WriteLine("Você empurrou a porta com dificuldade, ao levantar a cabeça, ao final do corredor, lá estava ele, o Rei.");
              Console.WriteLine("Sentado em seu trono, ele fala com você com a ajuda do ecoar do salão:'Parece que enfim você me achou' seus dentes roçam, e ele sorri.");
              Console.WriteLine("Ele se levanta lentamente, e pega seu cetro;'Por mais que eu quisesse comparecer ao local, quis ficar cara a cara com você Josh', vinha muitas coisas em sua mente, mas o fato era, ele não poderia continuar vivo. ");
              Console.WriteLine("1 - Duelar");

              string escolha2 = Console.ReadLine() ?? "";

              if(escolha2 == "1")
                {
                  DueloRei();   
                }
            }
            }
            else
            {
              Console.WriteLine("Você contorna o caminho, porém.. por que?");
              Console.WriteLine("1 - Empurrar");

              string escolha3 = Console.ReadLine() ?? "";

              if(escolha3 == "1")
                {
                  Console.WriteLine("Você empurrou a porta com dificuldade, ao levantar a cabeça, ao final do corredor, lá estava ele, o Rei.");
                  Console.WriteLine("Sentado em seu trono, ele fala com você com a ajuda do ecoar do salão:'Parece que enfim você me achou' seus dentes roçam, e ele sorri.");
                  Console.WriteLine("Ele se levanta lentamente, e pega seu cetro;'Por mais que eu quisesse comparecer ao local, quis ficar cara a cara com você Josh', vinha muitas coisas em sua mente, mas o fato era, ele não poderia continuar vivo. ");
                  Console.WriteLine("1 - Duelar");

                  string escolha4 = Console.ReadLine() ?? "";

                  if(escolha4 == "1")
                    {
                     DueloRei();   
                    }
                }   
            }
        }

        static void vingança()
        {
          Console.Clear();
          Console.WriteLine("Ele te explica o plano passo a passo, vocês não tem armas, porém tem inteligência.");
          Console.WriteLine("No dia seguinte vocês foram lá, e o vilarejo tava um caos, pessoas correndo para lá e para cá, lutando entre si:'Ali! Veja!, ele aponta para o grupo de marginais que você viu anteontem.");
          Console.WriteLine("A pessoa então diz que são eles os culpados disto tudo, mas quando você se vira ele está indo para os fundos de uma casa qualquer:'Há pessosas aqui que não se importam com o vilarejo, mandam em tudo, até no Rei.");
          Console.WriteLine("Ele te mostra uma passagem secreta, você desce junto dele:'Quem são vocês?' perguntou um encapuzado:");
          Console.WriteLine("1 - Avançar nele");
          Console.WriteLine("2 - Esperar");

          string escolha = Console.ReadLine() ?? "";

          if(escolha == "1")
            {
              Console.WriteLine("Você tenta chutar o encapuzado, quase que da errado, você acerta, e seu novo amigo finaliza ele:'Vamos.'");
              Console.WriteLine("1");

              string escolha2 = Console.ReadLine() ?? "";

              if(escolha == "1")
                {
                  lideres();  
                }
            }
        }

        static void bixo()
        {
          Console.Clear();
          Console.WriteLine("");   
        }

        static void DueloRei()
        {
            Console.Clear();
            Console.WriteLine("");
        }

    }

    static  void lideres()
    {
      Console.Clear();
      Console.WriteLine("");  
    }
}